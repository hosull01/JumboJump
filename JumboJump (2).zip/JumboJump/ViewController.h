//
//  ViewController.h
//  JumboJump
//

//  Copyright (c) 2014 David Pointeau. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface ViewController : UIViewController

@end
