//
//  MyScene.h
//  JumboJump
//

//  Copyright (c) 2014 David Pointeau. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface MyScene : SKScene

@end
