//
//  EndGameScene.h
//  JumboJump
//
//  Created by David Pointeau on 24/04/14.
//  Copyright (c) 2014 David Pointeau. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface EndGameScene : SKScene

@end
